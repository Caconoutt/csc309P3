
const SingleNoti = ({msg}) =>{
    return <>
    
    <div class="conta">
        <p>{msg}</p>
    </div>
    
    </>
}

export default SingleNoti